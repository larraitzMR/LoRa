/*
 * uart.h
 *
 *  Created on: 9 ago. 2017
 *      Author: Larraitz
 */

void UART_Config(void);
void UART2_Init(void);

